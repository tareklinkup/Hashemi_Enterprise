<div class="col-md-3"></div>
<div class="col-md-6" style="margin: auto;">

    <h1 style="background:#CDF9C9; color: #29A21C; text-align: center; font-size: 18px; font-weight: bold; padding: 20px; margin-top: 50px; width: 100%; border-radius:5px; " align="center">User Access Define Successfully</h1>
  
</div> 
